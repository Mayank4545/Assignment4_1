package com.corejava.package1;

import java.util.Scanner;

import com.corejava.assignment4.Assignment4_1;  /*import the package from where method will be called */ 

public class Assignment4_1_Calling extends Assignment4_1{
	
	public int method(int a, int b){
		int c = sum(a,b); /* Calling protected method */
		return c;
	}
	
//	Main Method
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter first number :");
		int a = s.nextInt();
		System.out.println("Enter second number :");
		int b = s.nextInt();
		
		Assignment4_1_Calling obj = new Assignment4_1_Calling();
		int c = obj.method(a,b); /* Calling public method to call Protected method */
		System.out.println("Sum = " + c);
	}
}

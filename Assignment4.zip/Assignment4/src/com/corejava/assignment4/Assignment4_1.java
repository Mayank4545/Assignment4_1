package com.corejava.assignment4;

public class Assignment4_1 {
	
	protected int sum(int a , int b){
		int c;
		System.out.println("Protected method calling..");
		c = a + b;
		return c;
	}
}